#!/usr/bin/env python

import sys
import rospy	
import cv2


from rviz_handler.msg import Flag
from sensor_msgs.msg import Image
from color_tracker.msg import Pos

import time
import RobotArm
import Communication
import StringHandler
x1 = 0
y1 = 0
x2 = 0
y2 = 0
a1 = 0
a2 = 0
chk = 0
aux = 0

def moveRobo(robotInstance, x, y, z, a ): #266.0
	print 'Vou mudar'
	print x, y, z, a

	try:
	        robotInstance.moveCartesianPosition(x, y, z, a, 180, 10)
	except Exception, e:
		print 'DEU RUIM'
		print e
	pass


def flagCheck(data):

	global chk

	if (data.flag1 == False) and (data.flag2 == False) and (data.flag3 == True) and (data.fase == 1):

		chk = 1

	elif (data.flag1 == False) and (data.flag2 == False) and (data.flag3 == True) and (data.fase == 2):

		chk = 2

def callback(data):

	global x1
	global x2
	global y1
	global y2
	global a1
	global a2


	global chk 
	global aux
	#rospy.loginfo("X1 %s  Y1 %s theta1 %s \n X2 %s Y2 %s theta2 %s", data.x1, data.y1, data.a1, data.x2, data.y2, data.a2)

	if aux == 0:

		x1 = data.x1
		y1 = data.y1
		x2 = data.x2
		y2 = data.y2
		a1 = data.a1
		a2 = data.a2
		aux = 1



	if chk == 1:


		print "o"
        	moveRobo(robot, x1, y1, 320, round(a1, 2))
		robot.handClose()
        	moveRobo(robot, x1, y1, 275, round(a1, 2))
		robot.handOpen()
        	moveRobo(robot, x1, y1, 290, round(a1, 2))
		chk = 0
		flag.flag1 = True
		flag.flag2 = False
		flag.flag3 = False
		flag.fase = 2
		pub.publish(flag)

	elif chk == 2:

        	moveRobo(robot, x2, y2, 320, round(a2, 2))
        	moveRobo(robot, x2, y2, 275, round(a2, 2))
		robot.handClose()
        	moveRobo(robot, x2, y2, 290, round(a2, 2))
		chk = 0
		flag.flag1 = True
		flag.flag2 = False
		flag.flag3 = False
		flag.fase = 3
		pub.publish(flag)

		
        
        


def main():

	global flag
	global pub
	global rate

	rospy.init_node('move', anonymous = True)

	rospy.Subscriber('Posicao', Pos, callback) 

	rospy.Subscriber('/Flag', Flag, flagCheck)

	pub = rospy.Publisher('Flag', Flag, queue_size = 10)
	rate = rospy.Rate(100)
	
	flag = Flag()
	rospy.loginfo(flag)

	rospy.spin()


if __name__ == '__main__':
	
	robot = RobotArm.RobotArm()
	#robot.init()
	#moveRobo(robot, 230, 0, 290, 0)
	main()



