#!/usr/bin/env python

import sys
import rospy	
import cv2


from std_msgs.msg import Bool
from sensor_msgs.msg import JointState
from math import pi

import time
import RobotArm
import Communication
import StringHandler
from std_msgs.msg import Bool
from rviz_handler.msg import Flag

posDeg = [0, 0, 0, 0, 0]
posCheck = [0, 0, 0, 0, 0]
matriz = []
chk = 0

def moveJoint(robotInstance, j1, j2, j3, j5, j6): #266.0
	print 'Vou mudar'
	print "\n j1 = %s \n j2 = %s \n j3 = %s \n j5 = %s \n j6 = %s", j1, j2, j3, j5, j6

	try:
	        robotInstance.moveJointPosition(j1, j2, j3, j5, j6, 10)
	except Exception, e:
	        print 'DEU RUIM'
	        print e
		pass

def flagCheck(data):

	global chk

	if (data.flag1 == False) and (data.flag2 == True) and (data.flag3 == False) and (data.fase == 1):

		chk = 1

	elif (data.flag1 == False) and (data.flag2 == True) and (data.flag3 == False) and (data.fase == 2):

		chk = 2

	elif (data.flag1 == False) and (data.flag2 == True) and (data.flag3 == False) and (data.fase == 3):

		chk = 3



def callback(data):

	global posDeg
	global posCheck
	global matriz
	global chk

	#rospy.loginfo("\n J1 %s \n J2 %s \n J3 %s \n J4 %s \n J5 %s \n", data.position[0], data.position[1], data.position[2], data.position[3], data.position[4]) 
	aux = 0
	for pos in range(5):

		if posCheck[pos] == data.position[pos]:

            		posCheck[pos] = posCheck[pos]

           		posDeg[pos] = data.position[pos] * 180/pi

           		aux = aux + 1

        	else:

          		posCheck[pos] = data.position[pos]

			posDeg[pos] = data.position[pos] * 180/pi

	teste = list(posDeg)
	if aux < 5:

	        matriz.append(teste)
	        aux = 0

	print matriz
    
	cv2.namedWindow("testee")
	key = cv2.waitKey(3) & 0xFF

	#if key == ord('m'):

	if chk == 1:

		for j in matriz:
			print matriz
			
			#moveJoint(robo, round(j[0], 2), round(j[1], 2),round(j[2], 2),round(j[3], 2),round(j[4], 2))
			moveJoint(robo, j[0], j[1], j[2], j[3], j[4])
		matriz = []
		
		flag.flag1 = False
		flag.flag2 = False
		flag.flag3 = True
		flag.fase = 1
		pub.publish(flag)
		chk = 0

	elif chk == 2:

		for j in matriz:
			print matriz
			
			#moveJoint(robo, round(j[0], 2), round(j[1], 2),round(j[2], 2),round(j[3], 2),round(j[4], 2))
			moveJoint(robo, j[0], j[1], j[2], j[3], j[4])
		matriz = []
		
		flag.flag1 = False
		flag.flag2 = False
		flag.flag3 = True
		flag.fase = 2
		pub.publish(flag)
		chk = 0

	elif chk == 3:

		for j in matriz:
			print matriz
			
			#moveJoint(robo, round(j[0], 2), round(j[1], 2),round(j[2], 2),round(j[3], 2),round(j[4], 2))
			moveJoint(robo, j[0], j[1], j[2], j[3], j[4])
		matriz = []
		
		flag.flag1 = False
		flag.flag2 = False
		flag.flag3 = False
		flag.fase = 0
		pub.publish(flag)
		chk = 0

def main():

	global flag
	global pub
	global rate


	rospy.init_node('move', anonymous = True)

	rospy.Subscriber('/joint_states', JointState , callback) 

	rospy.Subscriber('/Flag', Flag, flagCheck)

	pub = rospy.Publisher('Flag', Flag, queue_size = 10)
	rate = rospy.Rate(100)
	
	flag = Flag()

	rospy.loginfo(flag)


	rospy.spin()


if __name__ == '__main__':
	
	robo = RobotArm.RobotArm()
	main()



