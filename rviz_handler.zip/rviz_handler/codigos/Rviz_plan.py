#!/usr/bin/env python
from moveit_msgs.msg import RobotState, Constraints, OrientationConstraint
import sys
import copy
import rospy
import cv2
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from color_tracker.msg import Pos
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
from rviz_handler.msg import Flag

x1 = 0
x2 = 0
y1 = 0
y2 = 0
a1 = 0
a2 = 0
aux = 0

def callback(data):

	global x1
	global x2
	global x3
	global y1
	global y2
	global y3
	global a1
	global a2
	global a3
	global aux

	#rospy.loginfo("X1 %s  Y1 %s theta1 %s \n X2 %s Y2 %s theta2 %s", data.x1, data.y1, data.a1, data.x2, data.y2, data.a2)

	if aux == 0:
	
		x1 = data.x1
		x2 = data.x2
		y1 = data.y1
		y2 = data.y2
		x3 = data.y3
		y3 = data.y3
		a1 = data.a1
		a2 = data.a2
		a3 = data.a3
		aux = 1

	cv2.namedWindow("Traj")
	key = cv2.waitKey(3) & 0xFF
		
	if key == ord('p'):
		
		#if flag == 1?
		plan1(x1, y1, a1)


def flagCheck(data):

	global x2
	global y2


	if (data.flag1 == True) and (data.flag2 == False) and (data.flag3 == False) and (data.fase == 2):

		plan2(x2, y2, a2)

	elif (data.flag1 == True) and (data.flag2 == False) and (data.flag3 == False) and (data.fase == 3):

		plan3()

def plan1(x1, y1, a1):

	flag.flag1 = True
	flag.flag2 = False
	flag.flag3 = False
	flag.fase = 1
	pub.publish(flag)

	robot = moveit_commander.RobotCommander()
	scene = moveit_commander.PlanningSceneInterface()

	waypoints = []
	wpose = group.get_current_pose().pose

    	#joint_goal = group.get_current_joint_values()
  	#joint_goal[0] = 1*pi/180
	#joint_goal[1] = 1*pi/180
	#joint_goal[2] = 1*pi/180
	#joint_goal[3] = 1*pi/180
	#joint_goal[4] = 1*pi/180
    	#group.go(joint_goal, wait=True)
	wpose.position.x = (x1*0.9857+1.1647)/1000.00
	wpose.position.y = (y1*0.98007+1.5862)/1000.00
	#wpose.position.z = (300.00*0.93848+49.246)/1000.00
	#wpose.orientation.y = 0.5
	#wpose.orientation.z = 0.5
	#wpose.orientation.x = 0.5
	waypoints.append(copy.deepcopy(wpose))



    	rate = rospy.Rate(1)
 	
    	rate.sleep()	

	(plan, fraction) = group.compute_cartesian_path(
			                               waypoints,   # waypoints to follow
			                               0.01,        # eef_step
			                               0.0)         # jump_threshold	
	#group.stop()
	group.execute(plan, wait=True)
	flag.flag1 = False
	flag.flag2 = True
	flag.flag3 = False
	flag.fase = 1
	pub.publish(flag)


def plan2(x2, y2, a2):
	
	robot = moveit_commander.RobotCommander()
	scene = moveit_commander.PlanningSceneInterface()

	waypoints = []
	wpose = group.get_current_pose().pose

	wpose.position.x = (x2*0.9857+1.1647)/1000.00
	wpose.position.y = (y2*0.98007+1.5862)/1000.00
	print "x2 "
	print (x2*0.9857+1.1647)/1000.00
	print "y2"
	print (y2*0.98007+1.5862)/1000.00
	#print (y2*0.98007-1.5862)/1000.00
	#wpose.position.z = (300.00*0.93848+49.246)/1000.00
	#wpose.orientation.y = 0.5
	#wpose.orientation.z = 0.5
	#wpose.orientation.x = 0.5
	waypoints.append(copy.deepcopy(wpose))



    	rate = rospy.Rate(1)
 	
    	rate.sleep()	

	(plan, fraction) = group.compute_cartesian_path(
			                               waypoints,   # waypoints to follow
			                               0.01,        # eef_step
			                               0.0)         # jump_threshold	
	#group.stop()
	group.execute(plan, wait=True)
	flag.flag1 = False
	flag.flag2 = True
	flag.flag3 = False
	flag.fase = 2
	pub.publish(flag)

def plan3():
	
	global aux

	robot = moveit_commander.RobotCommander()
	scene = moveit_commander.PlanningSceneInterface()

	waypoints = []
	wpose = group.get_current_pose().pose

    	joint_goal = group.get_current_joint_values()
  	joint_goal[0] = -49.76*pi/180
	joint_goal[1] = 53.33*pi/180
	joint_goal[2] = 65.57*pi/180
	joint_goal[3] = 61.10*pi/180
	joint_goal[4] = -49.76*pi/180
    	group.go(joint_goal, wait=True)

	rate = rospy.Rate(1)
 	
    	rate.sleep()	

	group.stop()

	flag.flag1 = False
	flag.flag2 = True
	flag.flag3 = False
	flag.fase = 3
	pub.publish(flag)
	aux = 0



def main():

	global group
	global pub
	global rate
	global flag

	rospy.init_node('movePonto', anonymous = True)

	rospy.Subscriber('/Posicao', Pos, callback) 

	rospy.Subscriber('/Flag', Flag, flagCheck)

	pub = rospy.Publisher('Flag', Flag, queue_size = 10)
	rate = rospy.Rate(100)

	flag = Flag()
	flag.flag1 = False
	flag.flag2 = False
	flag.flag3 = False
	flag.fase = 0

	rospy.loginfo(flag)
	pub.publish(flag)
 
	moveit_commander.roscpp_initialize(sys.argv)
 
	display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path', moveit_msgs.msg.DisplayTrajectory,queue_size=20) 

	group = moveit_commander.MoveGroupCommander("rv2aj_arm")

	group_variable_values = group.get_current_joint_values() 

	group.set_joint_value_target(group_variable_values)

	rate.sleep()

	rospy.spin() 

if __name__ == '__main__':


	main()		




