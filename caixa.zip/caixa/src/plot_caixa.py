#!/usr/bin/env python
import sys
import rospy	
import cv2


from std_msgs.msg import Bool
from color_tracker.msg import Pos
from caixa.msg import Posicao
from math import pi

import time

def callback(data):
	global coordenadas
	rospy.loginfo("X1 %s  Y1 %s theta1 %s \n X2 %s Y2 %s theta2 %s", data.x3, data.y3, data.a1, data.x2, data.y2, data.a2)
	cv2.namedWindow("teste")
	key = cv2.waitKey(5) & 0xFF
	if key == ord("r"):
	#pub = rospy.Publisher('Caixapos', Posicao, queue_size = 10)
	#coordenadas = Posicao()	
		coordenadas.x1 = data.x3
		coordenadas.y1 = data.y3
		coordenadas.a1 = data.a3 * pi/180
	#rospy.loginfo(coordenadas)	
		pub.publish(coordenadas)
    		rate.sleep()
	if key == 27:
	 	cv2.destroyAllWindows()    	

def main():

	global coordenadas
	global pub
	global rate
	rospy.init_node('caixa', anonymous = True)
	rospy.Subscriber('/Posicao', Pos, callback) 
	pub = rospy.Publisher('Caixapos', Posicao, queue_size = 10)
	coordenadas = Posicao()
	rate = rospy.Rate(3)
	rospy.loginfo(coordenadas)
	rospy.spin()     


if __name__ == '__main__':
	main()		   
