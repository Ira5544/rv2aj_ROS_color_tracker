#!/usr/bin/env python

import sys
import rospy	
import cv2


from std_msgs.msg import Bool
from sensor_msgs.msg import Image
from color_tracker.msg import Pos

import time
import RobotArm
import Communication
import StringHandler
x = 230
y = 0

def moveRobo(robotInstance, x, y, z, a ): #266.0
    print 'Vou mudar'
    print x, y, z, a

    try:
        robotInstance.moveCartesianPosition(x, y, z, a, 180, 10)
    except Exception, e:
        print 'DEU RUIM'
        print e
    pass



def callback(data):
    rospy.loginfo("X1 %s  Y1 %s theta1 %s \n X2 %s Y2 %s theta2 %s", data.x1, data.y1, data.a1, data.x2, data.y2, data.a2)
    cv2.namedWindow("teste")
    key = cv2.waitKey(5) & 0xFF

    global x
    global y

    if key == ord("r"):
        robot.handClose()
        moveRobo(robot, x, y, 290, 0)
    	moveRobo(robot, 230, 0, 290, 0)

    if key == ord("p"):
        robot.handClose()
        moveRobo(robot, 230, 0, 290, 0)

    if key == ord("m"):
        print data.a1
        print data.a2
        
    	#moveRobo(robot, 230, 0, 290, round(data.a, 2))
    	# moveRobo(robot, data.x, data.y, 290, round(data.a, 2))
        x = data.x1
        y = data.y1

        #moveRobo(robot, 230, 0, 290, 70)
    	#moveRobo(robot, data.x, data.y, 290, 180)
        moveRobo(robot, data.x1, data.y1, 290, round(data.a1, 2))
        moveRobo(robot, data.x1, data.y1, 268, round(data.a1, 2))
        robot.handOpen()
        cv2.waitKey(300)
        moveRobo(robot, data.x1, data.y1, 290, round(data.a1, 2))
        moveRobo(robot, data.x2, data.y2, 290, round(data.a2, 2))
        moveRobo(robot, data.x2, data.y2, 280, round(data.a2, 2))
        robot.handClose()
        moveRobo(robot, data.x2, data.y2, 290, round(data.a2, 2))
        moveRobo(robot, 230, 0, 290, 0)
        # moveRobo(robot, data.x2, data.y2, 280, round(data.a2, 2))
        # moveRobo(robot, data.x1, data.y1, 290, round(data.a1, 2))
        # moveRobo(robot, data.x1, data.y1, 272, round(data.a1, 2))
        # moveRobo(robot, data.x1, data.y1, 290, round(data.a1, 2))
        #moveRobo(robot, data.x, data.y, 270, 180)
        #robot.handOpen()
        
        
    if key == 27:

    	cv2.destroyAllWindows()


def main():

	while not rospy.is_shutdown():

		rospy.init_node('move', anonymous = True)

		rospy.Subscriber('Posicao', Pos, callback) 

		rospy.spin()


if __name__ == '__main__':
	
	robot = RobotArm.RobotArm()
	robot.init()
	moveRobo(robot, 230, 0, 290, 0)
	main()



