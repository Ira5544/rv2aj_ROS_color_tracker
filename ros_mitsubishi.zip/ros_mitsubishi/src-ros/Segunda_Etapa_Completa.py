#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import cv2	
import rospy	
import numpy	
import imutils 

from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from collections import deque

import time
import RobotArm
import Communication
import StringHandler

bridge = CvBridge()
bgr_image = numpy.zeros((256, 256, 3), dtype = "uint8")

def callback(data):
    try:
        global bgr_image
        bgr_image = bridge.imgmsg_to_cv2(data, "bgr8")

    except CvBridgeError as e:
        print(e)

def retornaCalibracao(instanciaRospy, instanciaCv2):
    hmax = None
    hmin = None
    smax = None
    smin = None
    vmax = None
    vmin = None

    continuar = True

    while not instanciaRospy.is_shutdown() and continuar:
        hmax = instanciaCv2.getTrackbarPos('h_max', 'image')
        hmin = instanciaCv2.getTrackbarPos('h_min', 'image')
        smax = instanciaCv2.getTrackbarPos('s_max', 'image')
        smin = instanciaCv2.getTrackbarPos('s_min', 'image')
        vmax = instanciaCv2.getTrackbarPos('v_max', 'image')
        vmin = instanciaCv2.getTrackbarPos('v_min', 'image')

        hsv_image = instanciaCv2.cvtColor(bgr_image, instanciaCv2.COLOR_BGR2HSV)

        lower_hsv = numpy.array([hmin, smin, vmin])
        higher_hsv = numpy.array([hmax, smax, vmax])

        image = instanciaCv2.inRange(hsv_image, lower_hsv, higher_hsv)
        image = instanciaCv2.erode(image, None, iterations=2)
        image = instanciaCv2.dilate(image, None, iterations=2)

        mask = image.copy()
        frame = bgr_image.copy()

        instanciaCv2.imshow("image", image)
        instanciaCv2.imshow("frame", frame)

        key = instanciaCv2.waitKey(3)
    
        if key == ord("s"):
            continuar = False    
        
    return [hmax, hmin, smax, smin, vmax, vmin]

def retornaCoordenadas(instanciaRospy, instanciaCv2, dadosCalibracao):
    hsv_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2HSV)

    lower_hsv = numpy.array([dadosCalibracao[1], dadosCalibracao[3], dadosCalibracao[5]])
    higher_hsv = numpy.array([dadosCalibracao[0], dadosCalibracao[2], dadosCalibracao[4]])

    image = instanciaCv2.inRange(hsv_image, lower_hsv, higher_hsv)
    image = instanciaCv2.erode(image, None, iterations=2)
    image = instanciaCv2.dilate(image, None, iterations=2)

    mask = image.copy()
    frame = bgr_image.copy()

    contours = instanciaCv2.findContours(mask.copy(), instanciaCv2.RETR_EXTERNAL, instanciaCv2.CHAIN_APPROX_SIMPLE)
    contours = imutils.grab_contours(contours)

    if (len(contours) == 0):
        return None

    biggestContour = max(contours, key = instanciaCv2.contourArea)
    ((x, y), radius) = instanciaCv2.minEnclosingCircle(biggestContour)
    positionMoments = instanciaCv2.moments(biggestContour)
    center = (int(positionMoments["m10"] / positionMoments["m00"]), int(positionMoments["m01"] / positionMoments["m00"]))
    x = int(positionMoments["m10"] / positionMoments["m00"])
    y = int(positionMoments["m01"] / positionMoments["m00"])

    instanciaCv2.circle(frame, (int(x), int(y)), int(radius), (0, 255, 255), 1)
    instanciaCv2.circle(frame, center, 3, (0, 0, 255), -1)

    return (x, y)

def aplicaTransformada(x, y):

    #new_x = round((y*1.285)-40.66, 2)
    #new_y = round((x*1.285)-353.36, 2)
    #new_x = int((y/1.285)+ 35.15)
    #new_y = int((x/1.285)- 235.037)
    #new_x = int((150 + y)/1.32926)
    #new_y = int((x - 310)/1.27)
    new_x = int(y * 0.68 + 125)
    new_y = int(x * 0.727 - 249.18) 

    

    return (new_x, new_y)

   
def moveRobo(robotInstance, x, y, z = 275):
    #print 'Vou mudar'
    #print x, y, z

    try:
        robotInstance.moveCartesianPosition(x, y, z, 180, 180, 50)
    except Exception, e:
        #print 'DEU RUIM'
        print e

def main(args):

    robot = RobotArm.RobotArm()
    #incia as tarefas do robo
    robot.init() #inicia a conexao

    #Posição inicial
    moveRobo(robot, 140, 0, 400)

    image_sub = rospy.Subscriber("camera/rgb/image_color", Image, callback) 

    rospy.init_node('image_converter', anonymous = True)

    cv2.namedWindow('image')
    cv2.createTrackbar('h_max','image', 0, 255, lambda args: None)
    cv2.createTrackbar('h_min','image', 0, 255, lambda args: None)
    cv2.createTrackbar('s_max','image', 0, 255, lambda args: None)
    cv2.createTrackbar('s_min','image', 0, 255, lambda args: None)
    cv2.createTrackbar('v_max','image', 0, 255, lambda args: None)
    cv2.createTrackbar('v_min','image', 0, 255, lambda args: None)

    calibracao = retornaCalibracao(rospy, cv2)
    
    cv2.destroyAllWindows()
    
    pecas = 0
    tentativas = 0


    calibracao_peca_branca = [187, 111, 255, 0, 255, 236]
    calibracao_peca_azul = [255, 87, 255, 60, 255, 215]
    calibracao_peca_verde = [96, 62, 242, 79, 255, 117]
    calibracao_peca_vermelha = [81, 0, 214, 107, 236, 222]

    #Peças posição em ordem
    pecas_em_ordem = []

    #Calibração em ordem
    calibracoes_em_ordem = []

    while pecas < 4:
        user_input = raw_input("Insira corretamente a peça (aperte 's' para prosseguir): ")

        while user_input != 's':
            user_input = raw_input("Aperte 's' para prosseguir: ")

        branca = retornaCoordenadas(rospy, cv2, calibracao_peca_branca)
        azul = retornaCoordenadas(rospy, cv2, calibracao_peca_azul)
        verde = retornaCoordenadas(rospy, cv2, calibracao_peca_verde)
        vermelha = retornaCoordenadas(rospy, cv2, calibracao_peca_vermelha)

        if branca != None and calibracao_peca_branca not in calibracoes_em_ordem:
            pecas_em_ordem.append(branca)
            calibracoes_em_ordem.append(calibracao_peca_branca)
        elif azul != None and calibracao_peca_azul not in calibracoes_em_ordem:
            pecas_em_ordem.append(azul)
            calibracoes_em_ordem.append(calibracao_peca_azul)
        elif verde != None and calibracao_peca_verde not in calibracoes_em_ordem:
            pecas_em_ordem.append(verde)
            calibracoes_em_ordem.append(calibracao_peca_verde)
        elif vermelha != None and calibracao_peca_vermelha not in calibracoes_em_ordem:
            pecas_em_ordem.append(vermelha)
            calibracoes_em_ordem.append(calibracao_peca_vermelha)
        else:
            if tentativas > 2: 
                print 'Não consegui terminar, reinicie e tente novamente!'
                return
            else:
                print 'Não detectei a peça ou ela já está na lista, faça o passo novamente!'
                tentativas += 1
                continue

        pecas += 1
        tentativas = 0


    #posicao_inicial = aplicaTransformada (pecas_em_ordem[0])

    
    print ' '
    print '------------------------------'
    print 'Peças Escolhidas e Empilhadas!'
    print '------------------------------'
    print ' '

    time.sleep(2)

    print ' '
    print '------------------------------'
    print '      Hora de espalhá-las'
    print '------------------------------'
    print ' '

    z = 275
    z1 = 275
    #z1 = z0 + 20
    #z2 = z1 + 20
    #z3 = z2 + 20
    #z4 = z3 + 20

    #Pega as peças

    print ' '
    print ' '

    key2 = raw_input("Quando estiver pronto para empilhar insira a tecla s ")    
  
    while key2 != 's':
    	key2 = raw_input("Aperte 's' para prosseguir: ")

    print ' As peças serão empilhadas neste momento'

    #robot = RobotArm.RobotArm()
	#incia as tarefas do robo
    #robot.init() #inicia a conexao

    #Posição inicial
    moveRobo(robot, 140, 0, 400)

    #abre a garra (ao contrário o nome)
    robot.handClose() 

    i = 0
 
    for calibracao_peca in calibracoes_em_ordem:
        moveRobo(robot, 140, 0, 400) 

        peguei_peca = False
        tentativas_leitura_peca = 0

        while not peguei_peca and tentativas_leitura_peca < 5:
            print 'vou tentar pegar'
            coordenadas_peca = retornaCoordenadas(rospy, cv2, calibracao_peca)
            
            if coordenadas_peca == None:
                print "Tentando de novo."
                tentativas_leitura_peca += 1
                continue

            print 'achei a peca'
            (a, b) = aplicaTransformada(coordenadas_peca[0], coordenadas_peca[1])

            robot.handClose()
            print 'abri a garra'

            #movendo o robô para a peça
            moveRobo(robot, a, b, z1)
            print 'peguei a peca'
            robot.handOpen()
            print 'fechei a garra'

            #posição inicial do braço
            moveRobo(robot, 140, 0, 400)
            print 'abri a garra'

            coordenadas_peca = retornaCoordenadas(rospy, cv2, calibracao_peca)
            print coordenadas_peca
            
            if coordenadas_peca == None:
                print 'to com ela na mao'
                peguei_peca = True

        #se eu não consegui capturar a peça, vou capturar a proxima e deixo essa pra lá
        if not peguei_peca:
            print '\nNÃO CONSEGUI PEGAR PQ :/\n'
            continue

        moveRobo(robot, 234, -120, z)
        robot.handClose()
        moveRobo(robot, 234, -120, z + 30)

        z += 20
        i += 1
        
        print ' '
        print ' '
        print '-----------------------------'
        print 'Peça {} empilhada com sucesso!'.format(i)
        print '-----------------------------'
        print ' '


    #volta o robo para o inicio
    moveRobo(robot, 140, 0, 400) 
    robot.turnOff()

    print ' '
    print ' '
    print '-----------------------------'
    print '     Processo Finalizado!'
    print '     Peças Empilhadas'
    print '-----------------------------'

if __name__ == '__main__':
    main(sys.argv)
