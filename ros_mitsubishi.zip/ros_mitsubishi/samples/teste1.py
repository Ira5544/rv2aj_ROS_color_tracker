#!/usr/bin/env python
import os
path = os.getcwd() + '/src/ros_mitsubishi/src'

import sys
sys.path.insert(0, path)

import rospy
from ros_mitsubishi.msg import CartesianMessage

def talker():
	pub = rospy.Publisher('cartesianMovement', CartesianMessage, queue_size=1000)
	rospy.init_node('sample1', anonymous=True)

	cartesian = CartesianMessage(150.000, 0, 400.000, 180.000, 180.000, 100.0) #x, y, z, a, b, speed
	pub.publish(cartesian)
	cartesian = CartesianMessage(220.000, -95.000, 270.000, 180.000, 180.000, 100.0) #x, y, z, a, b, speed
	pub.publish(cartesian)

if __name__ == '__main__':
    talker()
