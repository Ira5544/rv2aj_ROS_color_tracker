#!/usr/bin/env python
import os
path = os.getcwd() + '/src/ros_mitsubishi/src'

import sys
sys.path.insert(0, path)

import rospy
from ros_mitsubishi.msg import CartesianMessage


def talker():
	pub = rospy.Publisher('cartesianMovement', CartesianMessage, queue_size=1000)
	rospy.init_node('sample1', anonymous=True)
	


   	cartesian = CartesianMessage(220, -90, 270, 180, 180, 30) #x, y, z, a, b, speed
	pub.publish(cartesian) 
	cartesian = CartesianMessage(320, -90, 270.000, 180, 180, 30) #x, y, z, a, b, speed
	pub.publish(cartesian)
	
	cartesian = CartesianMessage(150.000, 0, 400.000, 180, 180, 50) #x, y, z, a, b, speed
	pub.publish(cartesian)

if __name__ == '__main__':
    talker()
