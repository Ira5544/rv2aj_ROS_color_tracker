#!/usr/bin/env python
import sys
import cv2	
import rospy	
import numpy	
import imutils 

class ColorTracker :

	def calibration (h_max,h_min,s_max,s_min,v_max,v_min):






	def position_kinect(x,y):

		