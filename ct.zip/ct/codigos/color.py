#!/usr/bin/env python

import sys
import cv2
import rospy
import numpy
import imutils
import math
import time

from std_msgs.msg import Bool
from color_tracker.msg import Pos
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from collections import deque

bridge = CvBridge()
bgr_image = numpy.zeros((256, 256, 3), dtype = "uint8")

points = deque([], maxlen = 5000)
drawPath = False
# teste = False

def callback(data):
	try:

		global bgr_image
		bgr_image = bridge.imgmsg_to_cv2(data, "bgr8")

	except CvBridgeError as e:

		print e

# def callback2(data):

# 	global teste
# 	teste = data.data


def camera(args):

	rospy.init_node('color', anonymous = True)
	rospy.Subscriber("camera/rgb/image_color", Image, callback)

	cv2.namedWindow('imagem')
	cv2.namedWindow('imagemA')
	cv2.createTrackbar('h_maxA', 'imagemA', 110, 255, lambda args: None)
	cv2.createTrackbar('h_minA', 'imagemA', 76, 255, lambda args: None)
	cv2.createTrackbar('s_maxA', 'imagemA', 255, 255, lambda args: None)
	cv2.createTrackbar('s_minA', 'imagemA', 97, 255, lambda args: None)
	cv2.createTrackbar('v_maxA', 'imagemA', 255, 255, lambda args: None)
	cv2.createTrackbar('v_minA', 'imagemA', 149, 255, lambda args: None)

	cv2.namedWindow('imagemL')
	cv2.createTrackbar('h_maxL', 'imagemL', 71, 255, lambda args: None)
	cv2.createTrackbar('h_minL', 'imagemL', 0, 255, lambda args: None)
	cv2.createTrackbar('s_maxL', 'imagemL', 255, 255, lambda args: None)
	cv2.createTrackbar('s_minL', 'imagemL', 105, 255, lambda args: None)
	cv2.createTrackbar('v_maxL', 'imagemL', 255, 255, lambda args: None)
	cv2.createTrackbar('v_minL', 'imagemL', 186, 255, lambda args: None)

	cv2.namedWindow('imagemV')
	cv2.createTrackbar('h_maxV', 'imagemV', 108, 255, lambda args: None)
	cv2.createTrackbar('h_minV', 'imagemV', 48, 255, lambda args: None)
	cv2.createTrackbar('s_maxV', 'imagemV', 227, 255, lambda args: None)
	cv2.createTrackbar('s_minV', 'imagemV', 102, 255, lambda args: None)
	cv2.createTrackbar('v_maxV', 'imagemV', 195, 255, lambda args: None)
	cv2.createTrackbar('v_minV', 'imagemV', 113, 255, lambda args: None)

	cv2.namedWindow('imagemR')
	cv2.createTrackbar('h_maxR', 'imagemR', 255, 255, lambda args: None)
	cv2.createTrackbar('h_minR', 'imagemR', 113, 255, lambda args: None)
	cv2.createTrackbar('s_maxR', 'imagemR', 255, 255, lambda args: None)
	cv2.createTrackbar('s_minR', 'imagemR', 66, 255, lambda args: None)
	cv2.createTrackbar('v_maxR', 'imagemR', 255, 255, lambda args: None)
	cv2.createTrackbar('v_minR', 'imagemR', 66, 255, lambda args: None)

	#cv2.namedWindow('imagemVr')
	#cv2.createTrackbar('h_maxVr', 'imagemVr', 29, 255, lambda args: None)
	#cv2.createTrackbar('h_minVr', 'imagemVr', 0, 255, lambda args: None)
	#cv2.createTrackbar('s_maxVr', 'imagemVr', 255, 255, lambda args: None)
	#cv2.createTrackbar('s_minVr', 'imagemVr', 13, 255, lambda args: None)
	#cv2.createTrackbar('v_maxVr', 'imagemVr', 255, 255, lambda args: None)
	#cv2.createTrackbar('v_minVr', 'imagemVr', 194, 255, lambda args: None)

	cv2.namedWindow('imagemOB')
	cv2.createTrackbar('h_maxOB', 'imagemOB', 255, 255, lambda args: None)
	cv2.createTrackbar('h_minOB', 'imagemOB', 0, 255, lambda args: None)
	cv2.createTrackbar('s_maxOB', 'imagemOB', 255, 255, lambda args: None)
	cv2.createTrackbar('s_minOB', 'imagemOB', 0, 255, lambda args: None)
	cv2.createTrackbar('v_maxOB', 'imagemOB', 255, 255, lambda args: None)
	cv2.createTrackbar('v_minOB', 'imagemOB', 255, 255, lambda args: None)




	cv2.namedWindow('filtros')
	cv2.createTrackbar('KernelXY', 'filtros', 20, 100, lambda args: None)
	cv2.createTrackbar('iterations', 'filtros', 2, 20, lambda args: None)





	#x1 = 0
	#y1 = 0
	a = 0

	#x2 = 0
	#y2 = 0
	b = 0

	c = 0

	new_x_A = 0
	new_y_A = 0

	new_x_L = 0
	new_y_L = 0

	new_x_L1 = 0
	new_y_L1 = 0

	new_x_V = 0
	new_y_V = 0

	new_x_R = 0
	new_y_R = 0

	g = 0

	# p1X = 0.001532
	# p2X = -1.099
	# p3X = 261.22
	# p4X = -20211

	# p1Y = -0.0011812
	# p2Y = 0.97676
	# p3Y = -269.82
	# p4Y = 24906


	continuar = True

	font = cv2.FONT_HERSHEY_COMPLEX

	while not rospy.is_shutdown() and continuar:

		# rospy.Subscriber("esta_em_movimento", Bool, callback2 )

		hmaxA = cv2.getTrackbarPos('h_maxA', 'imagemA')
		hminA = cv2.getTrackbarPos('h_minA', 'imagemA')
		smaxA = cv2.getTrackbarPos('s_maxA', 'imagemA')
		sminA = cv2.getTrackbarPos('s_minA', 'imagemA')
		vmaxA = cv2.getTrackbarPos('v_maxA', 'imagemA')
		vminA = cv2.getTrackbarPos('v_minA', 'imagemA')

		hmaxL = cv2.getTrackbarPos('h_maxL', 'imagemL')
		hminL = cv2.getTrackbarPos('h_minL', 'imagemL')
		smaxL = cv2.getTrackbarPos('s_maxL', 'imagemL')
		sminL = cv2.getTrackbarPos('s_minL', 'imagemL')
		vmaxL = cv2.getTrackbarPos('v_maxL', 'imagemL')
		vminL = cv2.getTrackbarPos('v_minL', 'imagemL')

		hmaxV = cv2.getTrackbarPos('h_maxV', 'imagemV')
		hminV = cv2.getTrackbarPos('h_minV', 'imagemV')
		smaxV = cv2.getTrackbarPos('s_maxV', 'imagemV')
		sminV = cv2.getTrackbarPos('s_minV', 'imagemV')
		vmaxV = cv2.getTrackbarPos('v_maxV', 'imagemV')
		vminV = cv2.getTrackbarPos('v_minV', 'imagemV')

		hmaxR = cv2.getTrackbarPos('h_maxR', 'imagemR')
		hminR = cv2.getTrackbarPos('h_minR', 'imagemR')
		smaxR = cv2.getTrackbarPos('s_maxR', 'imagemR')
		sminR = cv2.getTrackbarPos('s_minR', 'imagemR')
		vmaxR = cv2.getTrackbarPos('v_maxR', 'imagemR')
		vminR = cv2.getTrackbarPos('v_minR', 'imagemR')

		#hmaxVr = cv2.getTrackbarPos('h_maxVr', 'imagemVr')
		#hminVr = cv2.getTrackbarPos('h_minVr', 'imagemVr')
		#smaxVr = cv2.getTrackbarPos('s_maxVr', 'imagemVr')
		#sminVr = cv2.getTrackbarPos('s_minVr', 'imagemVr')
		#vmaxVr = cv2.getTrackbarPos('v_maxVr', 'imagemVr')
		#vminVr = cv2.getTrackbarPos('v_minVr', 'imagemVr')

		hmaxOB = cv2.getTrackbarPos('h_maxOB', 'imagemOB')
		hminOB = cv2.getTrackbarPos('h_minOB', 'imagemOB')
		smaxOB = cv2.getTrackbarPos('s_maxOB', 'imagemOB')
		sminOB = cv2.getTrackbarPos('s_minOB', 'imagemOB')
		vmaxOB = cv2.getTrackbarPos('v_maxOB', 'imagemOB')
		vminOB = cv2.getTrackbarPos('v_minOB', 'imagemOB')

		KXY = cv2.getTrackbarPos('KernelXY', 'filtros')
		ITER = cv2.getTrackbarPos('iterations', 'filtros')

		hsv_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2HSV)

		lower_hsvA = numpy.array([hminA, sminA, vminA])
		higher_hsvA = numpy.array([hmaxA, smaxA, vmaxA])

		imageA = cv2.inRange(hsv_image, lower_hsvA, higher_hsvA)
		imageA = cv2.morphologyEx(imageA, cv2.MORPH_OPEN, (KXY,KXY), iterations = ITER)
		imageA = cv2.erode(imageA, (KXY, KXY), iterations = ITER - 1)
		maskA = imageA.copy()

		lower_hsvL = numpy.array([hminL, sminL, vminL])
		higher_hsvL = numpy.array([hmaxL, smaxL, vmaxL])

		imageL = cv2.inRange(hsv_image, lower_hsvL, higher_hsvL)
		imageL = cv2.morphologyEx(imageL, cv2.MORPH_OPEN, (KXY,KXY), iterations = ITER)
		imageL = cv2.erode(imageL, (KXY, KXY), iterations = ITER - 1)
		maskL = imageL.copy()

		lower_hsvV = numpy.array([hminV, sminV, vminV])
		higher_hsvV = numpy.array([hmaxV, smaxV, vmaxV])

		imageV = cv2.inRange(hsv_image, lower_hsvV, higher_hsvV)
		imageV = cv2.morphologyEx(imageV, cv2.MORPH_OPEN, (KXY,KXY), iterations = ITER)
		imageR = cv2.erode(imageV, (KXY,KXY), iterations = ITER - 1)
		maskV = imageV.copy()

		lower_hsvR = numpy.array([hminR, sminR, vminR])
		higher_hsvR = numpy.array([hmaxR, smaxR, vmaxR])

		imageR = cv2.inRange(hsv_image, lower_hsvR, higher_hsvR)
		imageR = cv2.morphologyEx(imageR, cv2.MORPH_OPEN, (KXY,KXY), iterations = ITER)
		imageR = cv2.erode(imageR, (KXY,KXY), iterations = ITER - 1)
		maskR = imageR.copy()

		#lower_hsvVr = numpy.array([hminVr, sminVr, vminVr])
		#higher_hsvVr = numpy.array([hmaxVr, smaxVr, vmaxVr])

		#imageVr = cv2.inRange(hsv_image, lower_hsvVr, higher_hsvVr)
		#imageVr = cv2.morphologyEx(imageVr, cv2.MORPH_OPEN, (KXY,KXY), iterations = ITER)
		#imageVr = cv2.erode(imageVr, (KXY,KXY), iterations = ITER - 1)
		#maskVr = imageVr.copy()

		lower_hsvOB = numpy.array([hminOB, sminOB, vminOB])
		higher_hsvOB = numpy.array([hmaxOB, smaxOB, vmaxOB])

		imageOB = cv2.inRange(hsv_image, lower_hsvOB, higher_hsvOB)
		imageOB = cv2.morphologyEx(imageOB, cv2.MORPH_OPEN, (KXY,KXY), iterations = ITER)
		imageOB = cv2.erode(imageOB, (KXY, KXY), iterations = ITER - 1)
		maskOB = imageOB.copy()


		image1 = cv2.bitwise_or(imageA, imageL)
		image2 = cv2.bitwise_or(imageR, imageV)
		#image3 = cv2.bitwise_or(imageVr, imageOB)
		#image = cv2.bitwise_or(image2, image3)
		image = cv2.bitwise_or(image1, image2)


		mask = image.copy()

		frame = bgr_image.copy()

		# global testedf4
		global drawPath

		if drawPath:

# ======================================  OBSTACULO VERMELHO ================================================================

			#contoursVr = cv2.findContours(maskVr.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
			#contoursVr = imutils.grab_contours(contoursVr)
			#centerVr = None

			#if len(contoursVr) > 0:

			 	#biggestContourVr = max(contoursVr, key = cv2.contourArea)
			 	#((x_Vr, y_Vr), radiusVr) = cv2.minEnclosingCircle(biggestContourVr)
			 	#positionMomentsVr = cv2.moments(biggestContourVr)

			 	#if positionMomentsVr["m00"] == 0:

			 		#points.clear()

			 		#pass

			 	#else:

			 	#	centerVr = (int(positionMomentsVr["m10"] / positionMomentsVr["m00"]), int(positionMomentsVr["m01"] / positionMomentsVr["m00"]))
		
			 	#	y_Vr = (positionMomentsVr["m10"] / positionMomentsVr["m00"])
			 	#	x_Vr = (positionMomentsVr["m01"] / positionMomentsVr["m00"])

					#new_x_A = x_A*0.7707 + 146.49
					#new_y_A = y_A*0.76526 - 243.3
	
				#	new_y_Vr = y_Vr*0.74073 - 174.3
				#	new_x_Vr = x_Vr*0.74038 + 158.27

			 	#	cv2.circle(frame, (int(y_Vr), int(x_Vr)), int(radiusVr), (0, 255, 255), 1)
			 	#	cv2.circle(frame, centerVr, 3, (0, 0, 255), -1)

			 	#	stringXY_Vr = 'X_Vr: ' + str(round(new_x_Vr, 2)) + ' Y_Vr: ' + str(round(new_y_Vr, 2))
				#	cv2.putText(frame, stringXY_Vr, (10, 110), font, 1, (255, 10, 10), 1)

# ======================================  OBSTACULO BRANCO ================================================================

			contoursOB = cv2.findContours(maskOB.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
			contoursOB = imutils.grab_contours(contoursOB)
			centerOB = None

			if len(contoursOB) > 0:

			 	biggestContourOB = max(contoursOB, key = cv2.contourArea)
			 	((x_OB, y_OB), radiusOB) = cv2.minEnclosingCircle(biggestContourOB)
			 	positionMomentsOB = cv2.moments(biggestContourOB)

			 	if positionMomentsOB["m00"] == 0:

			 		points.clear()

			 		pass

			 	else:

			 		centerOB = (int(positionMomentsOB["m10"] / positionMomentsOB["m00"]), int(positionMomentsOB["m01"] / positionMomentsOB["m00"]))
		
			 		y_OB = (positionMomentsOB["m10"] / positionMomentsOB["m00"])
			 		x_OB = (positionMomentsOB["m01"] / positionMomentsOB["m00"])

					#new_x_A = x_A*0.7707 + 146.49
					#new_y_A = y_A*0.76526 - 243.3
	
					new_y_OB = y_OB*0.73792 - 170.93
					new_x_OB = x_OB*0.72187 + 173.2

			 		cv2.circle(frame, (int(y_OB), int(x_OB)), int(radiusOB), (0, 255, 255), 1)
			 		cv2.circle(frame, centerOB, 3, (0, 0, 255), -1)

			 		#stringXY_OB = 'X_OB: ' + str(round(new_x_OB, 2)) + ' Y_OB: ' + str(round(new_y_OB, 2))
					#cv2.putText(frame, stringXY_OB, (10, 70), font, 1, (255, 10, 10), 1)

# ======================================  AZUL ================================================================

			contoursA = cv2.findContours(maskA.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
			contoursA = imutils.grab_contours(contoursA)
			centerA = None

			if len(contoursA) > 0:

			 	biggestContourA = max(contoursA, key = cv2.contourArea)
			 	((x_A, y_A), radiusA) = cv2.minEnclosingCircle(biggestContourA)
			 	positionMomentsA = cv2.moments(biggestContourA)

			 	if positionMomentsA["m00"] == 0:

			 		points.clear()

			 		pass

			 	else:

			 		centerA = (int(positionMomentsA["m10"] / positionMomentsA["m00"]), int(positionMomentsA["m01"] / positionMomentsA["m00"]))
		
			 		y_A = (positionMomentsA["m10"] / positionMomentsA["m00"])
			 		x_A = (positionMomentsA["m01"] / positionMomentsA["m00"])

					#new_x_A = x_A*0.7707 + 146.49
					#new_y_A = y_A*0.76526 - 243.3
	
					new_y_A = y_A*0.73792 - 170.93
					new_x_A = x_A*0.72187 + 173.2

			 		cv2.circle(frame, (int(y_A), int(x_A)), int(radiusA), (0, 255, 255), 1)
			 		cv2.circle(frame, centerA, 3, (0, 0, 255), -1)

			 		stringXY_A = 'X_A: ' + str(round(new_x_A, 2)) + ' Y_A: ' + str(round(new_y_A, 2))
					cv2.putText(frame, stringXY_A, (10, 70), font, 1, (255, 10, 10), 1)

# ======================================  LARANJA ================================================================

			contoursL = cv2.findContours(maskL.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
			contoursL = imutils.grab_contours(contoursL)
			centerL = None


			if len(contoursL) > 0:

				biggestContourL = max(contoursL, key = cv2.contourArea)
				((x_L, y_L), radiusL) = cv2.minEnclosingCircle(biggestContourL)
				positionMomentL = cv2.moments(biggestContourL)

				if positionMomentL["m00"] == 0:

					points.clear()

					pass

				else:

					centerL = (int(positionMomentL["m10"] / positionMomentL["m00"]), int(positionMomentL["m01"] / positionMomentL["m00"]))
			
					y_L = (positionMomentL["m10"] / positionMomentL["m00"])
					x_L = (positionMomentL["m01"] / positionMomentL["m00"])
			

					#new_x_L = x_L*0.7223 + 156.58
					#new_y_L = y_L*0.73966 - 237.16 	

					#new_y_L = y_L*0.72397 -174.81
					#new_x_L = x_L*0.74498 +160.03

					new_x_L = x_L*0.72187 + 173.2
					new_y_L = y_L*0.73792 - 170.93

					cv2.circle(frame, (int(y_L), int(x_L)), int(radiusL), (0, 255, 255), 1)
					cv2.circle(frame, centerL, 3, (0, 0, 255), -1)

					stringXY_L = 'X_L: ' + str(round(new_x_L, 2)) + ' Y_L: ' + str(round(new_y_L, 2))
					cv2.putText(frame, stringXY_L, (10, 420), font, 1, (255, 10, 10), 1)


# ======================================  VERDE ================================================================

			contoursV = cv2.findContours(maskV.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
			contoursV = imutils.grab_contours(contoursV)
			centerV = None

			if len(contoursV) > 0:

				biggestContourV = max(contoursV, key = cv2.contourArea)
				((x_V, y_V), radiusV) = cv2.minEnclosingCircle(biggestContourV)
				positionMomentsV = cv2.moments(biggestContourV)
				if positionMomentsV["m00"] == 0:


					points.clear()

					pass

				else:

					centerV = (int(positionMomentsV["m10"] / positionMomentsV["m00"]), int(positionMomentsV["m01"] / positionMomentsV["m00"]))
		
					y_V = (positionMomentsV["m10"] / positionMomentsV["m00"])
					x_V = (positionMomentsV["m01"] / positionMomentsV["m00"])

					#new_x_V = x_V*0.7223 + 155.58
					#new_y_V = y_V*0.73966 -235.16	
				
					new_y_V = y_V*0.73792 - 170.93
					new_x_V = x_V*0.72187 + 173.2 

					cv2.circle(frame, (int(y_V), int(x_V)), int(radiusV), (0, 255, 255), 1)
					cv2.circle(frame, centerV, 3, (0, 0, 255), -1)

					stringXY_V = 'X_V: ' + str(round(new_x_V, 2)) + ' Y_V: ' + str(round(new_y_V, 2))
					cv2.putText(frame, stringXY_V, (10, 460), font, 1, (255, 10, 10), 1)



# ======================================  ROXO ================================================================

			contoursR = cv2.findContours(maskR.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
			contoursR = imutils.grab_contours(contoursR)
			centerR = None

			if len(contoursR) > 0:

			 	biggestContourR = max(contoursR, key = cv2.contourArea)
			 	((x_R, y_R), radiusR) = cv2.minEnclosingCircle(biggestContourR)
			 	positionMomentsR = cv2.moments(biggestContourR)
			 	if positionMomentsR["m00"] == 0:

			 		points.clear()

			 		pass

			 	else:

			 		centerR = (int(positionMomentsR["m10"] / positionMomentsR["m00"]), int(positionMomentsR["m01"] / positionMomentsR["m00"]))
		
			 		y_R = (positionMomentsR["m10"] / positionMomentsR["m00"])
			 		x_R = (positionMomentsR["m01"] / positionMomentsR["m00"])
					#new_x_R = x_R*0.7707 + 145.49
					#new_y_R = y_R*0.76526 - 242.3	
					
					new_y_R = y_R*0.73792 - 170.93
					new_x_R = x_R*0.72187 + 173.2 

			 		cv2.circle(frame, (int(y_R), int(x_R)), int(radiusR), (0, 255, 255), 1)
			 		cv2.circle(frame, centerR, 3, (0, 0, 255), -1)

			 		stringXY_R = 'X_R: ' + str(round(new_x_R, 2)) + ' Y_R: ' + str(round(new_y_R, 2))
			 		cv2.putText(frame, stringXY_R, (10, 110), font, 1, (255, 10, 10), 1)


# ======================================  THETA A ================================================================

			(catetoAdjacenteLV, catetoOpostoLV) = numpy.array([new_x_V - new_x_L, new_y_V - new_y_L])
			hipotenusaLV = math.sqrt(catetoAdjacenteLV ** 2 + catetoOpostoLV ** 2)

			if (catetoOpostoLV == 0 or catetoAdjacenteLV == 0 or hipotenusaLV == 0 ):

				anguloPecaLV = 0

			anguloPecaLV = numpy.degrees(numpy.arcsin([catetoOpostoLV/hipotenusaLV]))

			stringXY_AnguloLV = 'theta1: ' + str(anguloPecaLV)

			cv2.putText(frame, stringXY_AnguloLV, (10, 380), font, 1, (255, 10, 10), 1)

# ======================= Primeiro Quadrante ====================================================
			if ((new_x_L - new_x_V) > 0 and (new_y_L - new_y_V) < 0 ):

				a = anguloPecaLV[0]

# ======================= Terceiro Quadrante ====================================================
			elif ((new_x_L - new_x_V) < 0 and (new_y_L - new_y_V) < 0):
            
				a = 180 - anguloPecaLV[0]

# ======================= Segundo Quadrante ====================================================

			elif ((new_x_L - new_x_V) < 0 and (new_y_L - new_y_V) > 0):   

				a = -180 - anguloPecaLV[0]

#============================ Quarto Quadrante =================================================================

			elif ((new_x_L - new_x_V) > 0 and (new_y_L - new_y_V) > 0):

				a = anguloPecaLV[0]
# ======================================  THETA B ================================================================
			(catetoAdjacenteAR, catetoOpostoAR) = numpy.array([new_x_R - new_x_A, new_y_R - new_y_A])
			hipotenusaAR = math.sqrt(catetoAdjacenteAR ** 2 + catetoOpostoAR ** 2)

			if (catetoOpostoAR == 0 or catetoAdjacenteAR == 0 or hipotenusaAR == 0 ):

			 	anguloPecaAR = 0

			anguloPecaAR = numpy.degrees(numpy.arcsin([catetoOpostoAR/hipotenusaAR]))

			stringXY_AnguloAR = 'theta2: ' + str(anguloPecaAR)

			cv2.putText(frame, stringXY_AnguloAR, (10, 30), font, 1, (255, 10, 10), 1)
# ======================= Quarto Quadrante ====================================================

			if ((new_x_A - new_x_R) > 0 and (new_y_A - new_y_R) < 0 ):

			 	b = anguloPecaAR[0]

# ======================= Terceiro Quadrante ====================================================

			elif ((new_x_A - new_x_R) < 0 and (new_y_A - new_y_R) < 0):
            
			 	b = 180 - anguloPecaAR[0]

# ======================= Segundo Quadrante ====================================================
			elif ((new_x_A - new_x_R) < 0 and (new_y_A - new_y_R) > 0):   

			 	b = -180 - anguloPecaAR[0]

#============================ Primeiro Quadrante =================================================

			elif ((new_x_A - new_x_R) > 0 and (new_y_A - new_y_R) > 0):

			 	b = anguloPecaAR[0]

# ======================================  THETA C ================================================================
			#(catetoAdjacenteOBVr, catetoOpostoOBVr) = numpy.array([new_x_Vr - new_x_OB, new_y_Vr - new_y_OB])
			#hipotenusaOBVr = math.sqrt(catetoAdjacenteOBVr ** 2 + catetoOpostoOBVr ** 2)

#			if (catetoOpostoOBVr == 0 or catetoAdjacenteOBVr == 0 or hipotenusaOBVr == 0 ):

#			 	anguloPecaOBVr = 0

#			anguloPecaOBVr = numpy.degrees(numpy.arcsin([catetoOpostoOBVr/hipotenusaOBVr]))

#			stringXY_AnguloOBVr = 'theta2: ' + str(anguloPecaOBVr)

			#cv2.putText(frame, stringXY_AnguloOBVr, (10, 30), font, 1, (255, 10, 10), 1)
# ======================= Quarto Quadrante ====================================================

#			if ((new_x_Vr - new_x_OB) < 0 and (new_y_Vr - new_y_OB) < 0 ):

#			 	c = -180 - anguloPecaOBVr[0]

# ======================= Terceiro Quadrante ====================================================

#			elif ((new_x_Vr - new_x_OB) < 0 and (new_y_Vr - new_y_OB) > 0):
            
			 	#c = 180 - anguloPecaOBVr[0]
#				c = anguloPecaOBVr[0]

# ======================= Segundo Quadrante ====================================================
#			elif ((new_x_Vr - new_x_OB) > 0 and (new_y_Vr - new_y_OB) > 0):   

			 	#c = anguloPecaOBVr[0]
#				c = -180 - anguloPecaOBVr[0]

#============================ Primeiro Quadrante =================================================

#			elif ((new_x_Vr - new_x_OB) > 0 and (new_y_Vr - new_y_OB) < 0):

#			 	c = anguloPecaOBVr[0]

#=================================================================================================

#			if ((c > -180 - 5) and (c < -180 + 5)) or ((c > 180 - 5) and (c < 180 + 5)) or ((c < 0 + 5) and (c > 0 - 5)):

#				c = 0

#			elif ((c > -90 - 5) and (c < -90 + 5)) or ((c > 90 - 5) and (c < 90 + 5)):

#				c = 90

			# if not centerL == None :
			# 	points.appendleft(centerL)

			# 	for i in range(1, len(points)):
			# 		if points[i - 1] is not None or points[i] is not None:
			# 			cv2.line(frame, points[i - 1], points[i], (0, 0, 255), 2)


			pub = rospy.Publisher('Posicao', Pos, queue_size = 10)
			rate = rospy.Rate(100)
			coordenadas = Pos()	
			coordenadas.x1 = round(new_x_L, 2)
			coordenadas.y1 = round(new_y_L, 2)
			coordenadas.x2 = round(new_x_A, 2)
			coordenadas.y2 = round(new_y_A, 2)
			coordenadas.x3 = round(new_x_OB, 2)#round((new_x_Vr + new_x_OB)/2, 2)
			coordenadas.y3 = round(new_y_OB, 2)#round((new_y_Vr + new_y_OB)/2, 2)
			coordenadas.a1 = round(a, 2)
			coordenadas.a2 = round(b, 2)
			coordenadas.a3 = round(c, 2)
			rospy.loginfo(coordenadas)
			print new_x_L
			print new_y_L
			pub.publish(coordenadas)

			rate.sleep()

			# if not center == None:

			# 	points.appendleft(center)

			# for i in range(1, len(points)):

			# 	if points[i - 1] is not None or points[i] is not None:

			# 		cv2.line(frame, points[i-1], points[i], (0, 0, 255), 2)

		# if teste == True:

		# 	drawPath = False 
		# 	teste = False

		cv2.imshow("imagem", image)
		cv2.imshow("imagemA", imageA)
		cv2.imshow("imagemL", imageL)
		cv2.imshow("imagemV", imageV)
		cv2.imshow("imagemR", imageR)
		cv2.imshow("imagemOB", imageOB)
		#cv2.imshow("imagemVr", imageVr)
		cv2.imshow("frame", frame)
		key = cv2.waitKey(1) & 0xFF

		if key  == ord("c"):

           		points.clear()

		if key  == ord("s"):

			drawPath = not drawPath

		# if key == ord("g"):
		# 	pub = rospy.Publisher('rvizPos', Pos, queue_size = 10)
		# 	rate = rospy.Rate(1)
		# 	coordenadas = Pos()	
		# 	coordenadas.x1 = round(new_x_L, 2)
		# 	coordenadas.y1 = round(new_y_L, 2)
		# 	coordenadas.x2 = round(new_x_A, 2)
		# 	coordenadas.y2 = round(new_y_A, 2)
		# 	coordenadas.a1 = round(a, 2)
		# 	coordenadas.a2 = round(b, 2)
		# 	rospy.loginfo(coordenadas)
		# 	print new_x_L
		# 	print new_y_L
		# 	pub.publish(coordenadas)	
			
		if key == 27:

			cv2.destroyAllWindows()


	while not rospy.is_shutdown():

		pass

	cv2.destroyAllWindows()

if __name__ == '__main__':

	try:
		camera(sys.argv)

	except (KeyboardInterrupt):

		print "Finalizado."
