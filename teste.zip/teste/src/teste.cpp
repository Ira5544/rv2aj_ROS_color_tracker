#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>

#include <moveit_msgs/DisplayRobotState.h>
#include <moveit_msgs/DisplayTrajectory.h>

#include <moveit_msgs/AttachedCollisionObject.h>
#include <moveit_msgs/CollisionObject.h>

#include <moveit_visual_tools/moveit_visual_tools.h>
#include "caixa/Posicao.h"
#include "color_tracker/Pos.h"
#include <iostream>

//int coordX=0;
//int coordY=0;
//float angulo=0;

// static const std::string PLANNING_GROUP = "rv2aj_arm";

// moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP);  

// const robot_state::JointModelGroup* joint_model_group =
//       move_group.getCurrentState()->getJointModelGroup(PLANNING_GROUP);

void chatterCallback(const caixa::Posicao::ConstPtr& msg)
{

int coordX=0;
int coordY=0;
float angulo=0;
  ROS_INFO("I heard: [%d]", msg -> x1);
  coordX = msg -> x1;
  ROS_INFO("I heard: [%d]", msg -> y1);
  coordY = msg -> y1;
  ROS_INFO("I heard: [%d]", msg -> a1);
  angulo = msg -> a1;


  static const std::string PLANNING_GROUP = "rv2aj_arm";

  moveit::planning_interface::PlanningSceneInterface planning_scene_interface;

  moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP);  

  // const robot_state::JointModelGroup* joint_model_group =
  //     move_group.getCurrentState()->getJointModelGroup(PLANNING_GROUP);

    // We can print the name of the reference frame for this robot.
  ROS_INFO_NAMED("tutorial", "Planning frame: %s", move_group.getPlanningFrame().c_str());

  // We can also print the name of the end-effector link for this group.
  ROS_INFO_NAMED("tutorial", "End effector link: %s", move_group.getEndEffectorLink().c_str());

  // We can get a list of all the groups in the robot:
  ROS_INFO_NAMED("tutorial", "Available Planning Groups:");
  //std::copy(move_group.getJointModelGroupNames().begin(), move_group.getJointModelGroupNames().end(),
           // std::ostream_iterator<std::string>(std::cout, ", "));    

  moveit_msgs::CollisionObject collision_object;
  collision_object.header.frame_id = move_group.getPlanningFrame();

  // The id of the object is used to identify it.
  collision_object.id = "box1";

  // Define a box to add to the world.
  shape_msgs::SolidPrimitive primitive;
  primitive.type = primitive.BOX;
  primitive.dimensions.resize(3);
  primitive.dimensions[0] = 0.05;
  primitive.dimensions[1] = 0.05;
  primitive.dimensions[2] = 0.08;

  // Define a pose for the box (specified relative to frame_id)
  geometry_msgs::Pose box_pose;
  box_pose.orientation.w = 1.0;
  box_pose.orientation.z = angulo;
  box_pose.position.x = ((coordX)*0.9857 + 1.1647)/1000;
  box_pose.position.y = ((coordY)*0.98007 + 1.5862)/1000;
  box_pose.position.z = 0.195;

  collision_object.primitives.push_back(primitive);
  collision_object.primitive_poses.push_back(box_pose);
  collision_object.operation = collision_object.ADD;

  std::vector<moveit_msgs::CollisionObject> collision_objects;
  collision_objects.push_back(collision_object);

  // Now, let's add the collision object into the world
  ROS_INFO_NAMED("tutorial", "Add an object into the world");
  planning_scene_interface.addCollisionObjects(collision_objects);

  //while(1){} 
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "teste");
  ros::NodeHandle node_handle;
  ros::Subscriber sub = node_handle.subscribe("/Caixapos", 1000, chatterCallback);
  ros::Rate loop_rate(1);
  // while (ros::ok())
  // {
  //   ros::spinOnce();
     loop_rate.sleep();
  // }
  ros::spin();
  // cout << "X1: " << coordX << "Y1: " << coordY << "\n";
  // ros::AsyncSpinner spinner(1);
  // spinner.start();
  return 0;
}
